import React, { Component } from 'react';
import axios from 'axios';
import update from 'immutability-helper';
import './TodosContainer.scss'

class TodosContainer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      todos: [],
      inputValue: '',
      inputDescription: '',
    };
  }

  getTodos() {
    axios.get('/api/v1/todos')
      .then(response => {
        this.setState({ todos: response.data });
      })
      .catch(error => console.log(error));
  }

  createTodo = (e) => {
    if (e.key === 'Enter' && !(e.target.value === '')) {
      axios.post('/api/v1/todos', { todo: { title: this.state.inputValue, description: this.state.inputDescription, done: false } })
        .then(response => {
          const todos = update(this.state.todos, {
            $splice: [[0, 0, response.data]]
          });
          this.setState({
            todos: todos,
            inputValue: '',
            inputDescription: '',
          });
        })
        .catch(error => console.log(error));
    }
  }

  handleChange = (e) => {
    this.setState({ inputValue: e.target.value });
  }

  handleDescriptionChange = (e) => {
    this.setState({ inputDescription: e.target.value });
  }

  // updateTodo = (e, id) => {
  //   axios.put(`/api/v1/todos/${id}`, { todo: { done: e.target.checked } })
  //     .then(response => {
  //       const todoIndex = this.state.todos.findIndex(x => x.id === response.data.id);
  //       const todos = update(this.state.todos, {
  //         [todoIndex]: { $set: response.data }
  //       });
  //       this.setState({
  //         todos: todos,
  //       });
  //     })
  //     .catch(error => console.log(error));
  // }
  updateTodo = (e, id) => {
    const updatedTodo = {
      done: e.target.checked,
      title: this.state.todos.find(todo => todo.id === id).title,
      description: this.state.todos.find(todo => todo.id === id).description
    };
  
    axios.put(`/api/v1/todos/${id}`, { todo: updatedTodo })
      .then(response => {
        const todoIndex = this.state.todos.findIndex(x => x.id === response.data.id);
        const todos = update(this.state.todos, {
          [todoIndex]: { $set: response.data }
        });
        this.setState({
          todos: todos,
        });
      })
      .catch(error => console.log(error));
  }
  

  deleteTodo = (id) => {
    axios.delete(`/api/v1/todos/${id}`)
      .then(response => {
        const todoIndex = this.state.todos.findIndex(x => x.id === id);
        const todos = update(this.state.todos, {
          $splice: [[todoIndex, 1]]
        });
        this.setState({
          todos: todos,
        });
      })
      .catch(error => console.log(error));
  }

  handleDescriptionKeyPress = (e) => {
	if (e.key === 'Enter' && !(e.target.value === '')) {
	  this.createTodo();
	}
  }
	  

  componentDidMount() {
    this.getTodos();
  }

  render() {
    return (
      <div className="todos-container">
        <div className="task-input-container">
          <input
            className="taskInput"
            type="text"
            placeholder="Add a task"
            maxLength="50"
            onKeyPress={this.createTodo}
            value={this.state.inputValue}
            onChange={this.handleChange}
          />
          <input
            className="descriptionInput"
            type="text"
            placeholder="Add a description"
			onKeyPress={this.createTodo} 
            value={this.state.inputDescription}
            onChange={this.handleDescriptionChange}
          />
        </div>
        <div className="task-list-wrapper">
          <ul className="task-list">
            {this.state.todos.map((todo) => {
              return (
                <li className="task" key={todo.id}>
                  <input
                    className="task-checkbox"
                    type="checkbox"
                    checked={todo.done}
                    onChange={(e) => this.updateTodo(e, todo.id)}
                  />
                  <label className={`task-label ${todo.done ? 'completed' : ''}`}>
                    {todo.title}
                  </label>
                  <span
                    className="deleteTaskBtn"
                    onClick={(e) => this.deleteTodo(todo.id)}
                  >
                    x
                  </span>
                  {todo.description && <p className="task-description">{todo.description}</p>}
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    );
  }
}

export default TodosContainer;
