Rails.application.routes.draw do
  scope '/api/v1' do
    resources :todos
  end
  get "up" => "rails/health#show", as: :rails_health_check

  # Defines the root path route ("/")
  # root "posts#index"
end
