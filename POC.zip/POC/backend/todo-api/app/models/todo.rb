class Todo < ApplicationRecord
end
